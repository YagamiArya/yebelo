package com.yebleo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FetchNextNumberApplicationTests {

	@Test
	void contextLoads() {
	}

}
